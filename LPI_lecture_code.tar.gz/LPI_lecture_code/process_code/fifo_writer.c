+#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h> 
#include <stdio.h> 
#include "errmacros.h"

#define FIFO_NAME 	"MYFIFO" 
#define MAX 		80
#define LOOPS		5

int main(void) { // FIFO reader
  FILE *fp; 
  int result;
  char *send_buf; 
  int i = LOOPS;
  
  /* Create the FIFO if it does not exist */ 
  result = mkfifo(FIFO_NAME, 0666);
  CHECK_MKFIFO(result); 	
  
  fp = fopen(FIFO_NAME, "w"); 
  printf("syncing with reader ok\n");
  FILE_OPEN_ERROR(fp);
  
  while ( i-- )
  {
    asprintf( &send_buf, "Test message %d\n", LOOPS-i );
    if ( fputs( send_buf, fp ) == EOF )
    {
      fprintf( stderr, "Error writing data to fifo\n");
      exit( EXIT_FAILURE );
    } 
    FFLUSH_ERROR(fflush(fp));
    printf("Message send: %s", send_buf); 
    free( send_buf );
    sleep(1);
  } 
  
  result = fclose( fp );
  FILE_CLOSE_ERROR(result);
  
  exit(EXIT_SUCCESS);
}





