
#define FIFO_NAME 	"logFifo" 


int write_to_fifo(char *str);
